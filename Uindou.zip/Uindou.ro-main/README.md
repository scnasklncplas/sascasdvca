<p align = "center">
  <img width="300" alt="webui" src="https://github.com/Zaque-69/Uindou/blob/main/assets/Untitled.png">
</p>

# What is Uindou?

> Uindou is a parody of Windows OS, which makes you think of Windows 95. It's a romanian website with a lot of refferences of celebrity people and current memes. :*

<img width="800" alt="webui" src="https://github.com/Zaque-69/Uindou/blob/main/assets/uindou2.png">
